import { get, set, reset, currentUser, HOME, ROLES } from './store.js';
import { screens } from './screens.js';
import { go, toast, confirmModal } from './ui.js';

const NAV = {
  donor: [['d/home', '🏠 Inicio'], ['d/alert', '🩸 Donar'], ['d/qr', '📅 Citas'], ['d/profile', '👤 Perfil']],
  medical: [['m/dashboard', 'Guardia'], ['m/new', 'Nueva solicitud'], ['m/radar', 'Radar'], ['m/reception', 'Recepción']],
  transport: [['t/assign', 'Requisición'], ['t/check', 'Custodia'], ['t/transit', 'Tránsito'], ['t/delivery', 'Entrega']],
  bank: [['b/dash', '▦ Dashboard'], ['b/appts', '👥 Donantes (Citas)'], ['b/fleet', '🧭 Radar Ambulancias'], ['b/reports', '📄 Reportes Historial']],
};
const app = document.getElementById('app');
let cleanup = null;

function parseHash() {
  const [path, qs] = (location.hash.slice(2) || 'login').split('?');
  return { path, q: Object.fromEntries(new URLSearchParams(qs)) };
}

function route() {
  cleanup?.(); cleanup = null;
  let { path, q } = parseHash();
  const user = currentUser(), screen = screens[path];
  if (!screen) return go(user ? HOME[user.role] : 'login');
  if (screen.role && (!user || user.role !== screen.role)) { toast('Inicia sesión con el rol correspondiente', 'err'); return go(user ? HOME[user.role] : 'login'); }
  if (!screen.role && user && ['login', 'register'].includes(path)) return go(HOME[user.role]);
  document.documentElement.dataset.theme = get().theme; document.body.dataset.role = user?.role || 'guest';
  const draw = () => {
    app.innerHTML = `<div class="page"><header class="hdr"><div class="logo" data-go="${user ? HOME[user.role] : 'splash'}"><i>🩸</i>VitalRed</div><div class="row" style="flex:none">${user ? `<div class="who"><b>${user.name}</b><small>${ROLES[user.role]}</small></div><button class="btn ghost sm" data-act="logout">Salir</button>` : ''}<button class="btn ghost sm" data-act="theme" aria-label="Cambiar tema">${get().theme === 'dark' ? '🌙' : '☀️'}</button></div></header>
    ${user ? `<nav class="tabs">${NAV[user.role].map(([r, l]) => `<a href="#/${r}" class="${r === path ? 'on' : ''}">${l}</a>`).join('')}</nav>` : ''}
    <main class="${screen.wide ? 'wide' : ''}">${screen.render({ q })}</main><footer>VitalRed v3.0 · Prototipo simulado · <a data-act="resetDemo">Reiniciar demo</a></footer></div>`;
    cleanup?.(); cleanup = screen.mount?.(app.querySelector('main'), draw) || null;
  };
  draw();
}

// ---------- Acciones ----------
const val = (id) => document.getElementById(id)?.value.trim() ?? '';
const sel = (name) => document.querySelector(`input[name="${name}"]:checked`)?.value;
const fail = (id, msg) => { const i = document.getElementById(id); i?.classList.add('bad'); const e = document.getElementById(id + '-err'); if (e) e.textContent = msg; return false; };
const clearErrs = () => { document.querySelectorAll('input.bad').forEach((i) => i.classList.remove('bad')); document.querySelectorAll('.err').forEach((e) => (e.textContent = '')); };
const enter = (user) => { set({ session: user.email }); toast(`Bienvenido, ${user.name.split(' ')[0]}`); go(HOME[user.role]); };
const patchReq = (p) => set({ req: { ...get().req, ...p } });
const idle = (ms, fn) => setTimeout(fn, ms);

const forms = {
  reg() { actions.regNext(); },
  login() {
    clearErrs();
    const email = val('email').toLowerCase(), password = val('password');
    let ok = true;
    if (!email) ok = fail('email', 'Ingresa tu correo o cédula');
    if (!password) ok = fail('password', 'Ingresa tu contraseña');
    if (!ok) return;
    const user = get().users.find((u) => u.email.toLowerCase() === email && u.password === password);
    if (!user) { fail('password', 'Credenciales incorrectas'); return toast('Correo o contraseña incorrectos', 'err'); }
    enter(user);
  },
  register(form) {
    clearErrs();
    const inst = form.dataset.role === 'inst', FOLIO = { MED: 'medical', TRA: 'transport', BAN: 'bank' };
    const role = inst ? FOLIO[val('folio').toUpperCase().slice(0, 3)] : 'donor', donor = role === 'donor';
    const name = val('name'), email = val('email').toLowerCase(), password = val('password');
    let ok = true;
    if (name.length < 3) ok = fail('name', 'Ingresa tu nombre completo');
    if (!email) ok = fail('email', 'Campo obligatorio');
    else if (!inst && !/^\S+@\S+\.\S+$/.test(email)) ok = fail('email', 'Correo con formato inválido');
    if (inst && !role) ok = fail('folio', 'Folio inválido (ej. MED-1024, TRA-2001, BAN-3005)');
    else if (get().users.some((u) => u.email === email)) ok = fail('email', 'Ya existe una cuenta con este dato');
    if (password.length < 6) ok = fail('password', 'Mínimo 6 caracteres');
    if (donor && !(sel('gender') && sel('age') && sel('weight'))) { ok = false; toast('Completa género, edad y peso', 'err'); }
    if (!donor && !val('hospital')) ok = fail('hospital', 'Indica tu institución');
    if (!ok) return;
    const user = { name, email, password, role };
    if (donor) {
      const risky = [0, 1, 2].some((i) => sel('risk' + i) === 'yes') || sel('fem') === 'yes';
      const eligible = sel('age') === 'adult' && sel('weight') === 'ok' && !risky;
      Object.assign(user, { blood: val('blood'), status: eligible ? 'Apto para donar' : 'Diferido temporalmente', donations: 0 });
    } else user.hospital = val('hospital');
    set({ users: [...get().users, user] });
    toast('Cuenta creada con éxito');
    enter(user);
  },
};

const missing = (names, d) => { const m = names.filter((n) => !d[n]); m.forEach((n) => document.querySelector(`[data-grp="${n}"]`)?.classList.add('grp-bad')); if (m.length) toast('Responde todas las preguntas para continuar', 'err'); return !m.length; };
const REG_RULES = {
  1: (d) => { let ok = true; if ((d.name || '').trim().length < 3) ok = fail('name', 'Ingresa tu nombre completo'); if (!/^\S+@\S+\.\S+$/.test(d.email || '')) ok = fail('email', 'Correo con formato inválido'); else if (get().users.some((u) => u.email === d.email.toLowerCase())) ok = fail('email', 'Ya existe una cuenta con este correo'); if ((d.password || '').length < 6) ok = fail('password', 'Mínimo 6 caracteres'); return ok; },
  2: (d) => missing(['gender', 'age', 'weight'], d),
  3: (d) => missing([0, 1, 2].map((i) => 'risk' + i).concat(d.gender === 'f' ? ['fem'] : []), d),
  4: (d) => d.terms || (toast('Acepta el aviso de privacidad', 'err'), false),
};
const actions = {
  eye(el) { const i = el.previousElementSibling, show = i.type === 'password'; i.type = show ? 'text' : 'password'; el.textContent = show ? '🙈' : '👁'; el.setAttribute('aria-pressed', show); el.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Mostrar contraseña'); },
  accept() { set({ inFlow: true }); },
  endFlow() { set({ inFlow: false }); toast('Cita cancelada'); },
  theme() { set({ theme: get().theme === 'dark' ? 'light' : 'dark' }); route(); },
  logout() { confirmModal('Cerrar sesión', '¿Deseas salir de VitalRed?', () => { set({ session: null }); toast('Sesión cerrada'); go('login'); }); },
  resetDemo() { confirmModal('Reiniciar demo', 'Se borrarán usuarios y datos creados.', () => { reset(); go('login'); route(); }); },
  demoAlert() { set({ req: { id: 'ST-2048', blood: 'O-', units: 2, priority: 'CRÍTICA', status: 'buscando', notified: 0, hospital: 'Hospital General' } }); go('d/alert'); },
  snooze() { set({ inFlow: false }); toast('Alerta pospuesta por 15 min', 'ok', { label: 'DESHACER (5s)', run: () => toast('Alerta reactivada') }); },
  filter(el) { set({ filter: el.dataset.v }); route(); },
  unit(el) { const u = document.getElementById('units'); u.textContent = Math.min(9, Math.max(1, +u.textContent + +el.dataset.d)); },
  pick(el) { set({ selAppt: el.dataset.id }); route(); },
  tab(el) { set({ apptTab: el.dataset.v }); route(); },
  authorize() { const id = get().selAppt || get().appts[0].id; set({ appts: get().appts.map((a) => (a.id === id ? { ...a, state: 'Extracción' } : a)) }); toast('Ingreso autorizado'); route(); },
  reject() { toast('Acceso rechazado', 'err'); },
  say(el) { toast(el.dataset.msg); },
  submitTriage() { set({ triageAns: [0, 1, 2, 3, 4].map((i) => sel('t' + i)) }); go('d/review'); },
  confirmTriage() { const pass = get().triageAns.every((v, i) => v === ['no', 'no', 'no', 'yes', 'yes'][i]); set({ triage: pass, inFlow: pass ? get().inFlow : false }); go(pass ? 'd/schedule' : 'd/rejected'); },
  regBack() { const r = get().reg; r.data = { ...r.data, ...Object.fromEntries(new FormData(document.getElementById('regForm'))) }; r.step = Math.max(1, r.step - 1); set({ reg: r }); route(); },
  regNext() {
    const r = get().reg, fd = Object.fromEntries(new FormData(document.getElementById('regForm')));
    r.data = { ...r.data, ...fd }; if (r.step === 4) r.data.terms = fd.terms;
    clearErrs(); document.querySelectorAll('.grp-bad').forEach((g) => g.classList.remove('grp-bad'));
    set({ reg: r }); if (!REG_RULES[r.step](r.data)) return;
    if (r.step < 4) { r.step++; set({ reg: r }); return route(); }
    const d = r.data, risky = [0, 1, 2].some((i) => d['risk' + i] === 'yes') || d.fem === 'yes', eligible = d.age === 'adult' && d.weight === 'ok' && !risky;
    const user = { name: d.name, email: d.email.toLowerCase(), password: d.password, role: 'donor', blood: d.blood || 'O+', status: eligible ? 'Apto para donar' : 'Diferido temporalmente', donations: 0 };
    set({ users: [...get().users, user], reg: null }); toast('¡Registro completado!'); enter(user);
  },
  confirmSlot() {
    const time = sel('slot'); if (!time) return toast('Elige un horario', 'err');
    const u = currentUser(), myAppt = { id: 'VR-2026-8891', name: u.name, time, state: 'Pre-Triaje' };
    set({ myAppt, appts: [myAppt, ...get().appts.filter((a) => a.id !== myAppt.id)] }); go('d/qr');
  },
  finishDonation() { set({ inFlow: false });
    const u = currentUser(); set({ users: get().users.map((x) => (x.email === u.email ? { ...x, donations: (x.donations || 0) + 1 } : x)), appts: get().appts.map((a) => (a.id === get().myAppt.id ? { ...a, state: 'Completada' } : a)) });
    go('d/done');
  },
  pdf() { go('d/pdf'); },
  print() { window.print(); },
  launch() {
    set({ req: { id: 'ST-' + (2049 + Math.floor(Math.random() * 50)), blood: sel('blood'), units: document.getElementById('units').textContent, priority: sel('priority'), status: 'buscando', notified: 0, hospital: currentUser().hospital || 'Hospital General' } });
    toast('Código Rojo lanzado'); go('m/radar');
  },
  cancelReq() {
    confirmModal('¿Deseas cancelar la búsqueda?', 'Afectará la atención del paciente.', () => {
      const prev = get().req; patchReq({ status: 'cancelada' }); go('m/none');
      toast('Solicitud cancelada', 'ok', { label: 'Deshacer (5s)', run: () => { set({ req: prev }); toast('Cancelación revertida'); go('m/radar'); } });
    }, 'Sí, cancelar');
  },
  noResp() { patchReq({ status: 'sinrespuesta' }); },
  retry() { patchReq({ status: 'buscando', notified: 0 }); toast('Ampliando radio a 15 km'); go('m/radar'); },
  external() { toast('Solicitud enviada a banco externo'); go('m/dashboard'); },
  scan(el) { el.classList.add('ok'); el.textContent = '✓ Código verificado'; },
  sign(el) { el.classList.add('ok'); el.textContent = currentUser().name; },
  receive() { patchReq({ status: 'completada' }); toast('Transfusión registrada'); go('m/dashboard'); },
  saveManual() { const t = parseFloat(val('manualTemp')); if (isNaN(t)) return fail('manualTemp', 'Ingresa una temperatura válida'); set({ temp: t }); toast('Registro manual guardado'); go('t/transit'); },
  heat() { set({ temp: 7.1 }); route(); },
  recal() { set({ temp: 4.6 }); toast('Sensor recalibrado, banco notificado'); route(); },
  deliver() { toast('Entrega finalizada y bitácora firmada'); set({ temp: 4.2 }); go('t/assign'); },
  scanAppt() {
    const next = get().appts.find((a) => !['Completada', 'No asistió'].includes(a.state));
    if (!next) return toast('No hay citas pendientes');
    const state = next.state !== 'Extracción' ? 'Extracción' : 'Completada';
    set({ appts: get().appts.map((a) => (a === next ? { ...a, state } : a)) }); toast(`${next.name}: ${state}`); route();
  },
  export() { toast('Reporte NOM-253 exportado (simulado)'); },
};
const EXPECTED_ANSWERS = ['no', 'no', 'no', 'yes', 'yes'];

document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-act],[data-go]'); if (!t || t.disabled) return;
  if (t.dataset.act) actions[t.dataset.act]?.(t);
  if (t.dataset.go && t.dataset.act !== 'cancelReq') go(t.dataset.go);
  t.dispatchEvent(new Event('selchange', { bubbles: true }));
});
document.addEventListener('change', (e) => e.target.dispatchEvent(new Event('selchange', { bubbles: true })));
document.addEventListener('submit', (e) => {
  e.preventDefault(); const f = e.target, b = f.querySelector('[type=submit]');
  if (!b) return forms[f.dataset.form]?.(f);
  b.classList.add('loading'); b.disabled = true;
  setTimeout(() => { b.classList.remove('loading'); b.disabled = false; forms[f.dataset.form]?.(f); }, 650);
});
addEventListener('hashchange', route);
route();

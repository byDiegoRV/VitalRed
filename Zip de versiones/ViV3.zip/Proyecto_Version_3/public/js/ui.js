export const go = (route) => { location.hash = '#/' + route; };
const attrs = (o) => `${o.go ? `data-go="${o.go}"` : ''} ${o.act ? `data-act="${o.act}"` : ''} ${o.id ? `id="${o.id}"` : ''} ${o.dis ? 'disabled' : ''} ${o.type ? `type="${o.type}"` : ''}`;
export const btn = (label, o = {}) => `<button class="btn ${o.v || 'primary'} ${o.cls || ''}" ${attrs(o)}>${label}</button>`;
export const card = (inner, cls = '') => `<section class="card ${cls}">${inner}</section>`;
export const badge = (text, color = '') => `<span class="badge ${color}">${text}</span>`;
export const field = (id, label, type = 'text', ph = '', val = '') => {
  const input = `<input id="${id}" name="${id}" type="${type}" placeholder="${ph}" value="${val}" autocomplete="off">`;
  const control = type === 'password' ? `<span class="pw">${input}<button type="button" class="eye" data-act="eye" aria-label="Mostrar contraseña" aria-pressed="false">👁</button></span>` : input;
  return `<label class="field"><span>${label}</span>${control}<small class="err" id="${id}-err"></small></label>`;
};
export const toggle = (name, options, cur, cls = '') =>
  `<div class="tog ${cls}" role="radiogroup" data-grp="${name}">${options.map(([v, l, sub]) => `<label class="tbtn"><input type="radio" name="${name}" value="${v}" ${String(cur) === String(v) ? 'checked' : ''}><span>${l}${sub ? `<small>${sub}</small>` : ''}</span></label>`).join('')}</div>`;
export const flow = (n, label) => `<div class="flow"><div class="flowbar">${[1, 2, 3, 4].map((i) => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</div><small class="lbl">PASO ${n} DE 4 · ${label}</small></div>`;
export const stepper = (steps, index) =>
  `<ol class="stepper">${steps.map((s, i) => `<li class="${i < index ? 'done' : i === index ? 'on' : ''}">${s}</li>`).join('')}</ol>`;
export const statusScreen = (icon, title, text, actions) =>
  card(`<div class="center stack"><div class="big">${icon}</div><h2>${title}</h2><p class="mut">${text}</p>${actions}</div>`);

export function toast(message, type = 'ok', action) {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${message}</span>${action ? `<button>${action.label}</button>` : ''}`;
  if (action) el.querySelector('button').onclick = () => { action.run(); el.remove(); };
  document.getElementById('toasts').append(el);
  setTimeout(() => el.remove(), action ? 5000 : 3200);
}
export function confirmModal(title, text, onOk, okLabel = 'Confirmar') {
  const m = document.createElement('div');
  m.className = 'modal';
  m.innerHTML = card(`<h2>${title}</h2><p class="mut" style="margin:8px 0 16px">${text}</p><div class="row"><button class="btn ghost" data-x>Volver</button><button class="btn primary" data-ok>${okLabel}</button></div>`);
  m.onclick = (e) => { if (e.target === m || e.target.dataset.x !== undefined) m.remove(); if (e.target.dataset.ok !== undefined) { m.remove(); onOk(); } };
  document.body.append(m);
}
export const qrPattern = (seed) => Array.from({ length: 121 }, (_, i) => `<i class="${((i * 7 + seed.length * (i % 5) + i * i) % 3) ? 'w' : ''}"></i>`).join('');
